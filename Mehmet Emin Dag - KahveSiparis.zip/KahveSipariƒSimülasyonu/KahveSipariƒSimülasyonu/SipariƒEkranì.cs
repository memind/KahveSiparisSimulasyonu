using KahveSiparişSimülasyonu.Abstract;
using KahveSiparişSimülasyonu.Concrete;
using KahveSiparişSimülasyonu.Enum;

namespace KahveSiparişSimülasyonu
{
    public partial class SiparişEkranı : Form
    {
        public SiparişEkranı()
        {
            InitializeComponent();
        }

        static IKafe kahveDukkani;
        static ICalisan calisan = new Calisan();
        private void SiparişEkranı_Load(object sender, EventArgs e)
        {
            cmbKahveTürü.Items.Add(KahveCesitleri.Latte);
            cmbKahveTürü.Items.Add(KahveCesitleri.Espresso);
            cmbKahveTürü.Items.Add(KahveCesitleri.Machiato);
            cmbKahveTürü.Items.Add(KahveCesitleri.TürkKahvesi);

            cmbEkSecim.Items.Add(KahveEkSeçimler.Ekstraİstemiyorum);
            cmbEkSecim.Items.Add(KahveEkSeçimler.Süt);
            cmbEkSecim.Items.Add(KahveEkSeçimler.Karamel);
            cmbEkSecim.Items.Add(KahveEkSeçimler.BeyazÇikolata);
            cmbEkSecim.Items.Add(KahveEkSeçimler.Çikolata);


        }
        
        private void btnKahveciyiAc_Click(object sender, EventArgs e)
        {

            kahveDukkani = new Kafe();
            kahveDukkani.MesaiBaşlat();
            
        }

        private void txtKasiyerSayisi_TextChanged(object sender, EventArgs e)
        {
            
            calisan.KasiyerSayisi = Convert.ToInt32(txtKasiyerSayisi.Text);
            lblKasiyer.Text = calisan.KasiyerSayisi.ToString();
            calisan.BaristaSayisi = 5 - calisan.KasiyerSayisi;
            lblBaristaSayisi.Text = calisan.BaristaSayisi.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Musteri mstr = new Musteri();
            Kasiyer kasa = new Kasiyer();

            kasa.SiparisAlabilirim += mstr.SiraGeldiMiKontrol();
            mstr.KasaBenGeldim += kasa.SiparisAl();
        }


        //private void cmbKasiyerSayısı_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (cmbKasiyerSayısı.SelectedIndex == 0)
        //    {
        //        // 6 çalışan var kasiyer seçimine göre diğeri kaç işlem yap

        //    }
        //}


    }
}