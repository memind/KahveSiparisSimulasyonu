﻿using KahveSiparişSimülasyonu.Abstract;
using KahveSiparişSimülasyonu.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KahveSiparişSimülasyonu.Concrete
{
    internal class Kasiyer : Calisan, IKasiyer
    {
        public event MusaitlikDurumuHaber SiparisAlabilirim;
        public event MusaitlikDurumuHaber SiparisiAlabilirsiniz;
        public event MusaitlikDurumuHaber SiparisAldim;


        public Kasiyer()
        {
            SiparisAlabilirim(this);
        }


        public void Musaitim(object sender) 
        {
            Musteri  musteri = sender as Musteri;

            musteri.KasaBenGeldim += this.SiparisAlabilirim;
            this.SiparisAlabilirim += this.SiparisAl;
        }

        public void SiparisAl(object sender)
        {
            Siparis siparis = new Siparis();

        }
    }
}
