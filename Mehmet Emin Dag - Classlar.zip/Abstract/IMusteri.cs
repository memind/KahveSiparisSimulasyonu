﻿using KahveSiparişSimülasyonu.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KahveSiparişSimülasyonu.Abstract
{
    internal interface IMusteri
    {
        public event MusaitlikDurumuHaber KasaBenGeldim;
        public void SiparisVer();
        public void SiraGeldiMiKontrol();
    }
}
