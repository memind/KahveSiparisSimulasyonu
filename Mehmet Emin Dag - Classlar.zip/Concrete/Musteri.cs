﻿using KahveSiparişSimülasyonu.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KahveSiparişSimülasyonu.Concrete
{
    internal class Musteri : IMusteri
    {
        public event MusaitlikDurumuHaber KasaBenGeldim;
        public void SiparisVer()
        {
            KasaBenGeldim(this);
        }

        public void SiraGeldiMiKontrol()
        {
            SiparisVer();
        }
    }
}
