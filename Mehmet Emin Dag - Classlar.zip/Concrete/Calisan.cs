﻿using KahveSiparişSimülasyonu.Abstract;

namespace KahveSiparişSimülasyonu.Concrete
{
    internal class Calisan : ICalisan
    {
        public List<ICalisan> Calisanlar { get; set; }

    }
}
